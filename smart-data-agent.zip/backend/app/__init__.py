"""Smart Data Agent backend package."""
