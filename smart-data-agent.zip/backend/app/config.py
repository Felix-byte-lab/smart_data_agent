from __future__ import annotations

from pathlib import Path

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    app_name: str = "Smart Data Agent"
    app_env: str = "dev"
    app_host: str = "0.0.0.0"
    app_port: int = 8000
    cors_origins: str = "http://localhost:3000"
    openai_api_key: str | None = None
    openai_base_url: str | None = None
    openai_model: str = "gpt-4o-mini"
    enable_llm: bool = False

    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")

    @property
    def backend_root(self) -> Path:
        return Path(__file__).resolve().parent.parent

    @property
    def project_root(self) -> Path:
        if self.backend_root.name == "backend":
            return self.backend_root.parent
        return self.backend_root

    @property
    def sqlite_path(self) -> Path:
        return self.project_root / "data" / "sqlite" / "demo.sqlite3"

    @property
    def knowledge_root(self) -> Path:
        return self.project_root / "knowledge_base"

    @property
    def knowledge_index_path(self) -> Path:
        return self.knowledge_root / "index.json"

    @property
    def allowed_origins(self) -> list[str]:
        return [item.strip() for item in self.cors_origins.split(",") if item.strip()]


settings = Settings()
