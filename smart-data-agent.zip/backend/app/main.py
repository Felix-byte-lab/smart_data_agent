from __future__ import annotations

from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.config import settings
from app.models import AppConfigPayload, ChatRequest, ChatResponse, KnowledgeDocument
from app.services.agent import SmartDataAgent
from app.services.knowledge_base import KnowledgeBase
from app.services.parser import QuestionParser
from app.services.query_executor import QueryExecutor
from app.services.session_store import SessionStore
from app.services.sql_builder import SqlBuilder
from app.services.sql_guard import SqlGuard


knowledge_base = KnowledgeBase(settings.knowledge_root, settings.knowledge_index_path)
agent = SmartDataAgent(
    knowledge_base=knowledge_base,
    parser=QuestionParser(),
    sql_builder=SqlBuilder(),
    sql_guard=SqlGuard(),
    query_executor=QueryExecutor(settings.sqlite_path),
    session_store=SessionStore(),
)


@asynccontextmanager
async def lifespan(_: FastAPI):
    yield


app = FastAPI(title=settings.app_name, version="0.1.0", lifespan=lifespan)
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.allowed_origins or ["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/health")
def health() -> dict[str, str]:
    return {"status": "ok"}


@app.get("/api/v1/config", response_model=AppConfigPayload)
def get_config() -> AppConfigPayload:
    return AppConfigPayload(
        app_name=settings.app_name,
        database_path=str(settings.sqlite_path),
        knowledge_documents=len(knowledge_base.list_documents()),
        llm_enabled=settings.enable_llm and bool(settings.openai_api_key),
    )


@app.get("/api/v1/knowledge/documents", response_model=list[KnowledgeDocument])
def list_knowledge_documents() -> list[KnowledgeDocument]:
    return knowledge_base.list_documents()


@app.post("/api/v1/chat/query", response_model=ChatResponse)
def chat_query(request: ChatRequest) -> ChatResponse:
    return agent.answer(request.question, request.session_id)
