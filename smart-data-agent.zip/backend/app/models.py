from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, Field


class KnowledgeReference(BaseModel):
    title: str
    source: str
    snippet: str
    score: float
    category: str


class ChartPayload(BaseModel):
    type: Literal["bar", "line", "table", "metric"]
    title: str
    description: str | None = None
    x_key: str | None = None
    y_key: str | None = None
    rows: list[dict[str, Any]] = Field(default_factory=list)


class DebugPayload(BaseModel):
    intent: str
    metric: str | None = None
    dimensions: list[str] = Field(default_factory=list)
    filters: dict[str, Any] = Field(default_factory=dict)
    time_range: str | None = None
    compare_mode: str | None = None


class ChatRequest(BaseModel):
    question: str = Field(min_length=1, max_length=500)
    session_id: str | None = None


class ChatResponse(BaseModel):
    session_id: str
    question: str
    mode: Literal["knowledge", "query", "hybrid"]
    summary: str
    answer: str
    explanation: str | None = None
    sql: str | None = None
    result_rows: list[dict[str, Any]] = Field(default_factory=list)
    chart: ChartPayload | None = None
    knowledge_refs: list[KnowledgeReference] = Field(default_factory=list)
    follow_up_questions: list[str] = Field(default_factory=list)
    debug: DebugPayload


class KnowledgeDocument(BaseModel):
    title: str
    category: str
    source: str
    preview: str


class AppConfigPayload(BaseModel):
    app_name: str
    database_path: str
    knowledge_documents: int
    llm_enabled: bool
