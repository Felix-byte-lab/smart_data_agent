from __future__ import annotations

import re

import sqlparse


class SqlGuardError(ValueError):
    pass


class SqlGuard:
    FORBIDDEN_PATTERNS = [
        r"\bdelete\b",
        r"\bupdate\b",
        r"\binsert\b",
        r"\bdrop\b",
        r"\balter\b",
        r"\btruncate\b",
        r";",
    ]

    def validate(self, sql: str) -> None:
        statement = sqlparse.format(sql, strip_comments=True).strip().lower()
        if not statement.startswith("select"):
            raise SqlGuardError("只允许执行 SELECT 查询。")

        for pattern in self.FORBIDDEN_PATTERNS:
            if re.search(pattern, statement):
                raise SqlGuardError(f"SQL 命中禁止模式：{pattern}")
