from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date, timedelta
from typing import Literal

from app.services.session_store import SessionContext


REGIONS = ["华东", "华北", "华南", "华中", "西南", "西北"]
CATEGORIES = ["饮料", "零食", "日化", "家居"]
STORES = ["上海旗舰店", "杭州湖滨店", "北京国贸店", "广州天河店", "成都太古里店", "西安曲江店"]

METRIC_SYNONYMS: dict[str, tuple[str, ...]] = {
    "sales_amount": ("销售额", "营收", "收入", "净销售额"),
    "gmv": ("gmv", "成交额", "毛销售额"),
    "order_count": ("订单数", "订单量"),
    "refund_rate": ("退款率", "退货率"),
    "avg_order_value": ("客单价",),
    "new_customers": ("新客数", "新增客户数"),
    "repurchase_rate": ("复购率",),
}

DIMENSION_SYNONYMS: dict[str, tuple[str, ...]] = {
    "region": ("区域", "大区"),
    "store": ("门店", "店铺"),
    "category": ("品类", "类目"),
    "product": ("商品", "产品"),
    "date": ("每日", "按日", "每天", "趋势", "日期"),
    "month": ("按月", "每月", "月度"),
}

METRIC_LABELS = {
    "sales_amount": "销售额",
    "gmv": "GMV",
    "order_count": "订单数",
    "refund_rate": "退款率",
    "avg_order_value": "客单价",
    "new_customers": "新客数",
    "repurchase_rate": "复购率",
}


@dataclass
class TimeRange:
    label: str
    start: date
    end: date


@dataclass
class ParsedQuestion:
    intent: Literal["knowledge", "query", "hybrid"]
    metric: str | None = None
    metric_label: str | None = None
    dimensions: list[str] = field(default_factory=list)
    filters: dict[str, str] = field(default_factory=dict)
    time_range: TimeRange | None = None
    compare_mode: str | None = None
    explain_mode: bool = False
    ranking: bool = False
    top_n: int | None = None


class QuestionParser:
    def parse(self, question: str, context: SessionContext) -> ParsedQuestion:
        normalized = question.lower()
        intent = self._detect_intent(normalized)

        metric = self._detect_metric(normalized) or context.metric
        dimensions = self._detect_dimensions(normalized, context)
        filters = self._detect_filters(question, context)
        time_range = self._detect_time_range(normalized) or self._range_from_context(context)
        compare_mode = self._detect_compare_mode(normalized)
        if compare_mode and time_range is None:
            today = date.today()
            time_range = TimeRange("本月", today.replace(day=1), today)
        explain_mode = any(keyword in normalized for keyword in ["为什么", "原因", "分析"])
        ranking, top_n = self._detect_ranking(normalized)

        if compare_mode and "date" not in dimensions and "month" not in dimensions and not ranking:
            dimensions = dimensions[:]

        return ParsedQuestion(
            intent=intent,
            metric=metric,
            metric_label=METRIC_LABELS.get(metric) if metric else None,
            dimensions=dimensions,
            filters=filters,
            time_range=time_range,
            compare_mode=compare_mode,
            explain_mode=explain_mode,
            ranking=ranking,
            top_n=top_n,
        )

    def _detect_intent(self, normalized: str) -> Literal["knowledge", "query", "hybrid"]:
        knowledge_keywords = ["什么是", "区别", "定义", "口径", "解释", "含义"]
        query_keywords = ["多少", "是多少", "趋势", "排名", "top", "对比", "环比", "同比"]
        has_knowledge = any(keyword in normalized for keyword in knowledge_keywords)
        has_query = any(keyword in normalized for keyword in query_keywords)
        if has_knowledge and has_query:
            return "hybrid"
        if has_knowledge:
            return "knowledge"
        return "query"

    def _detect_metric(self, normalized: str) -> str | None:
        for metric, words in METRIC_SYNONYMS.items():
            if any(word in normalized for word in words):
                return metric
        return None

    def _detect_dimensions(self, normalized: str, context: SessionContext) -> list[str]:
        dimensions: list[str] = []
        for dimension, words in DIMENSION_SYNONYMS.items():
            if any(word in normalized for word in words):
                dimensions.append(dimension)

        if "各区域" in normalized or "按区域" in normalized:
            dimensions.append("region")
        if "各门店" in normalized or "按门店" in normalized:
            dimensions.append("store")
        if "各品类" in normalized or "按品类" in normalized:
            dimensions.append("category")
        if "各商品" in normalized or "按商品" in normalized:
            dimensions.append("product")

        if not dimensions and any(word in normalized for word in ["比", "对比", "增长", "下降"]):
            dimensions = context.dimensions[:]

        return list(dict.fromkeys(dimensions))

    def _detect_filters(self, question: str, context: SessionContext) -> dict[str, str]:
        filters = dict(context.filters)
        for region in REGIONS:
            if region in question:
                filters["region"] = region
        for category in CATEGORIES:
            if category in question:
                filters["category"] = category
        for store in STORES:
            if store in question:
                filters["store"] = store
        return filters

    def _detect_time_range(self, normalized: str) -> TimeRange | None:
        today = date.today()
        if "今天" in normalized:
            return TimeRange("今天", today, today)
        if "昨天" in normalized:
            yesterday = today - timedelta(days=1)
            return TimeRange("昨天", yesterday, yesterday)
        if "近7天" in normalized or "最近7天" in normalized:
            return TimeRange("近7天", today - timedelta(days=6), today)
        if "近30天" in normalized or "最近30天" in normalized:
            return TimeRange("近30天", today - timedelta(days=29), today)
        if "本月" in normalized or "这个月" in normalized:
            start = today.replace(day=1)
            return TimeRange("本月", start, today)
        if "上月" in normalized:
            first_of_this_month = today.replace(day=1)
            end = first_of_this_month - timedelta(days=1)
            start = end.replace(day=1)
            return TimeRange("上月", start, end)
        if "本周" in normalized:
            start = today - timedelta(days=today.weekday())
            return TimeRange("本周", start, today)
        if "上周" in normalized:
            end = today - timedelta(days=today.weekday() + 1)
            start = end - timedelta(days=6)
            return TimeRange("上周", start, end)
        if "今年" in normalized:
            start = date(today.year, 1, 1)
            return TimeRange("今年", start, today)
        if "去年" in normalized:
            return TimeRange("去年", date(today.year - 1, 1, 1), date(today.year - 1, 12, 31))
        return None

    def _range_from_context(self, context: SessionContext) -> TimeRange | None:
        if not context.time_range:
            return None
        today = date.today()
        if context.time_range == "本月":
            return TimeRange("本月", today.replace(day=1), today)
        return None

    @staticmethod
    def _detect_compare_mode(normalized: str) -> str | None:
        if "同比" in normalized:
            return "yoy"
        if "环比" in normalized or "和上个月比" in normalized or "相比上月" in normalized:
            return "mom"
        return None

    @staticmethod
    def _detect_ranking(normalized: str) -> tuple[bool, int | None]:
        ranking = "排名" in normalized or "top" in normalized
        top_n = 5 if ranking else None
        if "top3" in normalized or "前三" in normalized:
            top_n = 3
        if "top10" in normalized or "前十" in normalized:
            top_n = 10
        return ranking, top_n
