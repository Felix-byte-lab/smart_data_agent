from __future__ import annotations

from math import fabs

from app.models import ChartPayload, ChatResponse, DebugPayload
from app.services.knowledge_base import KnowledgeBase
from app.services.parser import METRIC_LABELS, ParsedQuestion, QuestionParser
from app.services.query_executor import QueryExecutor
from app.services.session_store import SessionStore
from app.services.sql_builder import QueryPlan, SqlBuilder
from app.services.sql_guard import SqlGuard


class SmartDataAgent:
    def __init__(
        self,
        knowledge_base: KnowledgeBase,
        parser: QuestionParser,
        sql_builder: SqlBuilder,
        sql_guard: SqlGuard,
        query_executor: QueryExecutor,
        session_store: SessionStore,
    ) -> None:
        self.knowledge_base = knowledge_base
        self.parser = parser
        self.sql_builder = sql_builder
        self.sql_guard = sql_guard
        self.query_executor = query_executor
        self.session_store = session_store

    def answer(self, question: str, session_id: str | None) -> ChatResponse:
        context = self.session_store.get_or_create(session_id)
        context.remember_question(question)

        parsed = self.parser.parse(question, context)
        references = self.knowledge_base.search(question)

        if parsed.intent == "knowledge":
            response = self._answer_knowledge(question, context.session_id, references)
            self.session_store.save(context)
            return response

        plan = self.sql_builder.build(parsed)
        self.sql_guard.validate(plan.sql)
        rows = self.query_executor.run(plan.sql, plan.params)

        compare_value = None
        if plan.compare_sql and plan.compare_params is not None:
            self.sql_guard.validate(plan.compare_sql)
            compare_rows = self.query_executor.run(plan.compare_sql, plan.compare_params)
            if compare_rows:
                compare_value = float(compare_rows[0].get("metric_value") or 0)

        summary, answer, explanation = self._render_query_answer(parsed, rows, compare_value, references)
        chart = self._build_chart(parsed, rows, plan)
        follow_ups = self._build_follow_ups(parsed)

        context.metric = parsed.metric
        context.dimensions = parsed.dimensions[:]
        context.filters = parsed.filters.copy()
        context.time_range = parsed.time_range.label if parsed.time_range else context.time_range
        self.session_store.save(context)

        return ChatResponse(
            session_id=context.session_id,
            question=question,
            mode="hybrid" if parsed.intent == "hybrid" else "query",
            summary=summary,
            answer=answer,
            explanation=explanation,
            sql=plan.sql,
            result_rows=rows,
            chart=chart,
            knowledge_refs=references,
            follow_up_questions=follow_ups,
            debug=DebugPayload(
                intent=parsed.intent,
                metric=parsed.metric,
                dimensions=parsed.dimensions,
                filters=parsed.filters,
                time_range=parsed.time_range.label if parsed.time_range else None,
                compare_mode=parsed.compare_mode,
            ),
        )

    def _answer_knowledge(self, question: str, session_id: str, references):
        if not references:
            summary = "知识库里暂时没有命中相关定义。"
            answer = "这个问题更偏概念解释，但当前知识库没有检索到足够贴近的文档。你可以换一种问法，比如直接问某个指标的定义、计算公式或差异。"
            explanation = "建议改问：GMV 的定义是什么？退款率怎么计算？新客数的统计口径是什么？"
        else:
            top = references[0]
            summary = f"我优先命中了《{top.title}》这份知识文档。"
            answer = top.snippet
            explanation = "这类问题优先通过知识库回答，不需要执行 SQL。"

        return ChatResponse(
            session_id=session_id,
            question=question,
            mode="knowledge",
            summary=summary,
            answer=answer,
            explanation=explanation,
            sql=None,
            result_rows=[],
            chart=None,
            knowledge_refs=references,
            follow_up_questions=[
                "这个指标的计算公式是什么？",
                "它和其他相近指标有什么区别？",
                "如果要看趋势，应该怎么问？",
            ],
            debug=DebugPayload(intent="knowledge"),
        )

    def _render_query_answer(
        self,
        parsed: ParsedQuestion,
        rows: list[dict[str, object]],
        compare_value: float | None,
        references,
    ) -> tuple[str, str, str]:
        metric_label = parsed.metric_label or METRIC_LABELS.get(parsed.metric or "", "指标")
        time_label = parsed.time_range.label if parsed.time_range else "当前范围"

        if not rows:
            summary = "当前查询没有返回数据。"
            answer = "我已经生成并执行查询，但在当前时间与筛选条件下没有命中数据。你可以放宽时间范围，或者换一个区域 / 品类重试。"
            explanation = "出现空结果通常是因为过滤条件太严格，或者当前演示数据里没有对应样本。"
            return summary, answer, explanation

        if "metric_value" in rows[0] and len(rows) == 1 and len(rows[0]) == 1:
            current_value = float(rows[0]["metric_value"] or 0)
            summary = f"{time_label}的{metric_label}为 {self._format_metric(current_value, parsed.metric)}。"
            if compare_value is not None:
                delta = current_value - compare_value
                ratio = 0 if compare_value == 0 else delta / compare_value
                direction = "上升" if delta >= 0 else "下降"
                answer = (
                    f"{time_label}的{metric_label}是 {self._format_metric(current_value, parsed.metric)}，"
                    f"相较对比周期{direction} {self._format_metric(fabs(delta), parsed.metric)}，"
                    f"变化幅度约为 {ratio:.1%}。"
                )
            else:
                answer = f"{time_label}的{metric_label}是 {self._format_metric(current_value, parsed.metric)}。"

            explanation = "这个结果来自虚拟经营数据查询。若你继续追问“按区域拆分”或“和上月比”，我会沿用当前指标继续分析。"
            if parsed.intent == "hybrid" and references:
                explanation += f" 同时，我参考了《{references[0].title}》中的指标口径说明。"
            return summary, answer, explanation

        leading_dimension = next((key for key in rows[0].keys() if key != "metric_value"), "维度")
        best_row = rows[0]
        summary = (
            f"{time_label}按{self._dimension_label(leading_dimension)}查看时，"
            f"{best_row[leading_dimension]}的{metric_label}最高，为 {self._format_metric(float(best_row['metric_value'] or 0), parsed.metric)}。"
        )
        answer = (
            f"我按{self._dimension_label(leading_dimension)}返回了 {metric_label} 结果，"
            f"可以直接看到不同维度之间的差异分布。"
        )
        explanation = "如果你想继续深挖，可以接着问“只看华东”“按门店排名”或“和上个月比”。"
        return summary, answer, explanation

    def _build_chart(self, parsed: ParsedQuestion, rows: list[dict[str, object]], plan: QueryPlan) -> ChartPayload | None:
        if not rows:
            return None
        if len(rows) == 1 and list(rows[0].keys()) == ["metric_value"]:
            return ChartPayload(
                type="metric",
                title=parsed.metric_label or plan.label,
                description="单指标汇总结果",
                rows=rows,
            )

        keys = [key for key in rows[0].keys() if key != "metric_value"]
        x_key = keys[0] if keys else None
        return ChartPayload(
            type="line" if plan.chart_type == "line" else "bar",
            title=f"{parsed.metric_label or plan.label}图表",
            description="基于当前查询结果自动生成的可视化建议",
            x_key=x_key,
            y_key="metric_value",
            rows=rows[:20],
        )

    def _build_follow_ups(self, parsed: ParsedQuestion) -> list[str]:
        metric_label = parsed.metric_label or "这个指标"
        return [
            f"{metric_label}按区域拆分看看",
            f"{metric_label}和上个月比怎么样？",
            f"{metric_label}的口径定义是什么？",
        ]

    @staticmethod
    def _dimension_label(field_name: str) -> str:
        mapping = {
            "region_name": "区域",
            "store_name": "门店",
            "category_name": "品类",
            "product_name": "商品",
            "date": "日期",
            "month_label": "月份",
        }
        return mapping.get(field_name, field_name)

    @staticmethod
    def _format_metric(value: float, metric: str | None) -> str:
        if metric in {"refund_rate", "repurchase_rate"}:
            return f"{value:.2%}"
        if metric == "order_count" or metric == "new_customers":
            return f"{int(round(value))}"
        return f"{value:,.2f}"
