from __future__ import annotations

import sqlite3
from pathlib import Path


class QueryExecutor:
    def __init__(self, sqlite_path: Path) -> None:
        self.sqlite_path = sqlite_path

    def run(self, sql: str, params: list[object] | None = None) -> list[dict[str, object]]:
        with sqlite3.connect(self.sqlite_path) as connection:
            connection.row_factory = sqlite3.Row
            rows = connection.execute(sql, params or []).fetchall()
        return [dict(row) for row in rows]
