from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from uuid import uuid4


@dataclass
class SessionContext:
    session_id: str
    metric: str | None = None
    dimensions: list[str] = field(default_factory=list)
    filters: dict[str, str] = field(default_factory=dict)
    time_range: str | None = None
    history: list[str] = field(default_factory=list)
    updated_at: datetime = field(default_factory=datetime.utcnow)

    def remember_question(self, question: str) -> None:
        self.history.append(question)
        self.history = self.history[-8:]
        self.updated_at = datetime.utcnow()


class SessionStore:
    def __init__(self) -> None:
        self._store: dict[str, SessionContext] = {}

    def get_or_create(self, session_id: str | None) -> SessionContext:
        if session_id and session_id in self._store:
            return self._store[session_id]
        actual_session_id = session_id or str(uuid4())
        context = SessionContext(session_id=actual_session_id)
        self._store[actual_session_id] = context
        return context

    def save(self, context: SessionContext) -> None:
        context.updated_at = datetime.utcnow()
        self._store[context.session_id] = context
