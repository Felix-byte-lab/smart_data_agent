from __future__ import annotations

import json
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable

from app.models import KnowledgeDocument, KnowledgeReference


def _normalize_text(text: str) -> str:
    return re.sub(r"\s+", " ", text).strip().lower()


def _bigrams(text: str) -> set[str]:
    normalized = _normalize_text(text)
    if len(normalized) < 2:
        return {normalized} if normalized else set()
    return {normalized[i : i + 2] for i in range(len(normalized) - 1)}


@dataclass
class KnowledgeChunk:
    title: str
    source: str
    category: str
    content: str
    tags: list[str]

    @property
    def preview(self) -> str:
        plain = re.sub(r"[#>*`-]", " ", self.content)
        plain = re.sub(r"\s+", " ", plain).strip()
        return plain[:120] + ("…" if len(plain) > 120 else "")


class KnowledgeBase:
    def __init__(self, root: Path, index_path: Path) -> None:
        self.root = root
        self.index_path = index_path
        self._chunks: list[KnowledgeChunk] = self._load()

    def _load(self) -> list[KnowledgeChunk]:
        if self.index_path.exists():
            payload = json.loads(self.index_path.read_text(encoding="utf-8"))
            return [KnowledgeChunk(**item) for item in payload]
        return list(self._scan_markdown_files())

    def _scan_markdown_files(self) -> Iterable[KnowledgeChunk]:
        for path in sorted(self.root.rglob("*.md")):
            category = path.parent.name
            content = path.read_text(encoding="utf-8")
            title = self._extract_title(path, content)
            yield KnowledgeChunk(
                title=title,
                source=str(path.relative_to(self.root.parent)),
                category=category,
                content=content.strip(),
                tags=[category, path.stem],
            )

    @staticmethod
    def _extract_title(path: Path, content: str) -> str:
        for line in content.splitlines():
            stripped = line.strip()
            if stripped.startswith("# "):
                return stripped.removeprefix("# ").strip()
        return path.stem.replace("-", " ")

    def list_documents(self) -> list[KnowledgeDocument]:
        return [
            KnowledgeDocument(
                title=chunk.title,
                category=chunk.category,
                source=chunk.source,
                preview=chunk.preview,
            )
            for chunk in self._chunks
        ]

    def search(self, query: str, limit: int = 4) -> list[KnowledgeReference]:
        query_bigrams = _bigrams(query)
        query_terms = set(re.findall(r"[\w\u4e00-\u9fff]+", _normalize_text(query)))
        scored: list[KnowledgeReference] = []

        for chunk in self._chunks:
            content_norm = _normalize_text(f"{chunk.title} {chunk.content} {' '.join(chunk.tags)}")
            content_bigrams = _bigrams(content_norm)
            overlap = len(query_bigrams & content_bigrams)
            term_hits = sum(1 for term in query_terms if term and term in content_norm)
            score = overlap + term_hits * 2
            if score <= 0:
                continue

            snippet = chunk.preview
            scored.append(
                KnowledgeReference(
                    title=chunk.title,
                    source=chunk.source,
                    snippet=snippet,
                    score=round(float(score), 2),
                    category=chunk.category,
                )
            )

        return sorted(scored, key=lambda item: item.score, reverse=True)[:limit]
