from __future__ import annotations

from dataclasses import dataclass
from datetime import timedelta

from app.services.parser import ParsedQuestion, TimeRange


METRIC_SQL = {
    "sales_amount": "ROUND(SUM(f.net_sales), 2)",
    "gmv": "ROUND(SUM(f.gross_sales), 2)",
    "order_count": "SUM(f.order_count)",
    "refund_rate": "ROUND(CASE WHEN SUM(f.gross_sales)=0 THEN 0 ELSE SUM(f.refund_amount) * 1.0 / SUM(f.gross_sales) END, 4)",
    "avg_order_value": "ROUND(CASE WHEN SUM(f.order_count)=0 THEN 0 ELSE SUM(f.net_sales) * 1.0 / SUM(f.order_count) END, 2)",
    "new_customers": "SUM(f.new_customer_count)",
    "repurchase_rate": "ROUND(CASE WHEN SUM(f.active_customer_count)=0 THEN 0 ELSE SUM(f.returning_customer_count) * 1.0 / SUM(f.active_customer_count) END, 4)",
}

DIMENSION_SQL = {
    "region": ("r.region_name", "region_name"),
    "store": ("s.store_name", "store_name"),
    "category": ("c.category_name", "category_name"),
    "product": ("p.product_name", "product_name"),
    "date": ("d.date", "date"),
    "month": ("d.month_label", "month_label"),
}


@dataclass
class QueryPlan:
    sql: str
    params: list[object]
    label: str
    chart_type: str
    compare_sql: str | None = None
    compare_params: list[object] | None = None


class SqlBuilder:
    BASE_FROM = """
FROM fact_sales f
JOIN dim_date d ON d.date_key = f.date_key
JOIN dim_region r ON r.region_id = f.region_id
JOIN dim_store s ON s.store_id = f.store_id
JOIN dim_product p ON p.product_id = f.product_id
JOIN dim_category c ON c.category_id = p.category_id
""".strip()

    def build(self, parsed: ParsedQuestion) -> QueryPlan:
        metric_key = parsed.metric or "sales_amount"
        metric_sql = METRIC_SQL[metric_key]
        filters_sql, params = self._build_filters(parsed)

        if parsed.ranking and not parsed.dimensions:
            parsed.dimensions = ["region"]

        select_fields: list[str] = []
        group_by_fields: list[str] = []
        order_by = "metric_value DESC"
        chart_type = "metric"
        label = parsed.metric_label or "指标值"

        for dimension in parsed.dimensions:
            if dimension not in DIMENSION_SQL:
                continue
            expr, alias = DIMENSION_SQL[dimension]
            select_fields.append(f"{expr} AS {alias}")
            group_by_fields.append(expr)

        if select_fields:
            chart_type = "line" if parsed.dimensions == ["date"] or parsed.dimensions == ["month"] else "bar"

        sql = "SELECT "
        if select_fields:
            sql += ", ".join(select_fields) + ", "
        sql += f"{metric_sql} AS metric_value\n{self.BASE_FROM}\n{filters_sql}"

        if group_by_fields:
            sql += "\nGROUP BY " + ", ".join(group_by_fields)
            if parsed.ranking:
                sql += f"\nORDER BY {order_by}\nLIMIT {parsed.top_n or 5}"
            else:
                order_field = group_by_fields[0] if chart_type == "line" else order_by
                sql += f"\nORDER BY {order_field}"

        compare_sql = None
        compare_params = None
        if parsed.compare_mode and parsed.time_range:
            compare_range = self._build_compare_range(parsed.time_range, parsed.compare_mode)
            compare_filters_sql, compare_params = self._build_filters(parsed, override_time_range=compare_range)
            compare_sql = f"SELECT {metric_sql} AS metric_value\n{self.BASE_FROM}\n{compare_filters_sql}"

        return QueryPlan(
            sql=sql.strip(),
            params=params,
            label=label,
            chart_type=chart_type,
            compare_sql=compare_sql,
            compare_params=compare_params,
        )

    def _build_filters(
        self,
        parsed: ParsedQuestion,
        override_time_range: TimeRange | None = None,
    ) -> tuple[str, list[object]]:
        clauses = []
        params: list[object] = []
        active_range = override_time_range or parsed.time_range
        if active_range:
            clauses.append("d.date BETWEEN ? AND ?")
            params.extend([active_range.start.isoformat(), active_range.end.isoformat()])

        if parsed.filters.get("region"):
            clauses.append("r.region_name = ?")
            params.append(parsed.filters["region"])
        if parsed.filters.get("store"):
            clauses.append("s.store_name = ?")
            params.append(parsed.filters["store"])
        if parsed.filters.get("category"):
            clauses.append("c.category_name = ?")
            params.append(parsed.filters["category"])

        if not clauses:
            return "WHERE 1=1", params
        return "WHERE " + " AND ".join(clauses), params

    @staticmethod
    def _build_compare_range(current_range: TimeRange, compare_mode: str) -> TimeRange:
        duration = current_range.end - current_range.start
        if compare_mode == "mom":
            compare_end = current_range.start - timedelta(days=1)
            compare_start = compare_end - duration
            return TimeRange("上一个对比周期", compare_start, compare_end)
        if compare_mode == "yoy":
            return TimeRange(
                "去年同期",
                current_range.start.replace(year=current_range.start.year - 1),
                current_range.end.replace(year=current_range.end.year - 1),
            )
        return current_range
