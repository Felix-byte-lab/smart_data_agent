from __future__ import annotations

import random
import sqlite3
from dataclasses import dataclass
from datetime import date, timedelta
from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parents[1]
DB_PATH = PROJECT_ROOT / "data" / "sqlite" / "demo.sqlite3"


@dataclass
class Region:
    region_id: int
    region_name: str


@dataclass
class Store:
    store_id: int
    store_name: str
    region_id: int


@dataclass
class Category:
    category_id: int
    category_name: str


@dataclass
class Product:
    product_id: int
    product_name: str
    category_id: int


def build_dimension_data():
    regions = [
        Region(1, "华东"),
        Region(2, "华北"),
        Region(3, "华南"),
        Region(4, "华中"),
        Region(5, "西南"),
        Region(6, "西北"),
    ]
    stores = [
        Store(1, "上海旗舰店", 1),
        Store(2, "杭州湖滨店", 1),
        Store(3, "北京国贸店", 2),
        Store(4, "天津和平店", 2),
        Store(5, "广州天河店", 3),
        Store(6, "深圳万象店", 3),
        Store(7, "武汉天地店", 4),
        Store(8, "长沙IFS店", 4),
        Store(9, "成都太古里店", 5),
        Store(10, "重庆观音桥店", 5),
        Store(11, "西安曲江店", 6),
        Store(12, "兰州中心店", 6),
    ]
    categories = [
        Category(1, "饮料"),
        Category(2, "零食"),
        Category(3, "日化"),
        Category(4, "家居"),
    ]
    products = [
        Product(1, "气泡水", 1),
        Product(2, "冷萃咖啡", 1),
        Product(3, "坚果礼盒", 2),
        Product(4, "能量棒", 2),
        Product(5, "洗衣凝珠", 3),
        Product(6, "洗手液", 3),
        Product(7, "香薰蜡烛", 4),
        Product(8, "收纳箱", 4),
    ]
    return regions, stores, categories, products


def iter_dates(days: int = 240):
    end = date.today()
    start = end - timedelta(days=days - 1)
    current = start
    while current <= end:
        yield current
        current += timedelta(days=1)


def ensure_schema(conn: sqlite3.Connection) -> None:
    conn.executescript(
        """
        DROP TABLE IF EXISTS fact_sales;
        DROP TABLE IF EXISTS dim_date;
        DROP TABLE IF EXISTS dim_region;
        DROP TABLE IF EXISTS dim_store;
        DROP TABLE IF EXISTS dim_category;
        DROP TABLE IF EXISTS dim_product;

        CREATE TABLE dim_date (
            date_key INTEGER PRIMARY KEY,
            date TEXT NOT NULL,
            year INTEGER NOT NULL,
            month INTEGER NOT NULL,
            day INTEGER NOT NULL,
            week_of_year INTEGER NOT NULL,
            month_label TEXT NOT NULL
        );

        CREATE TABLE dim_region (
            region_id INTEGER PRIMARY KEY,
            region_name TEXT NOT NULL
        );

        CREATE TABLE dim_store (
            store_id INTEGER PRIMARY KEY,
            store_name TEXT NOT NULL,
            region_id INTEGER NOT NULL
        );

        CREATE TABLE dim_category (
            category_id INTEGER PRIMARY KEY,
            category_name TEXT NOT NULL
        );

        CREATE TABLE dim_product (
            product_id INTEGER PRIMARY KEY,
            product_name TEXT NOT NULL,
            category_id INTEGER NOT NULL
        );

        CREATE TABLE fact_sales (
            date_key INTEGER NOT NULL,
            region_id INTEGER NOT NULL,
            store_id INTEGER NOT NULL,
            product_id INTEGER NOT NULL,
            order_count INTEGER NOT NULL,
            quantity INTEGER NOT NULL,
            gross_sales REAL NOT NULL,
            refund_amount REAL NOT NULL,
            net_sales REAL NOT NULL,
            new_customer_count INTEGER NOT NULL,
            returning_customer_count INTEGER NOT NULL,
            active_customer_count INTEGER NOT NULL
        );
        """
    )


def seed() -> None:
    random.seed(20261106)
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)

    regions, stores, categories, products = build_dimension_data()

    with sqlite3.connect(DB_PATH) as conn:
        ensure_schema(conn)
        conn.executemany(
            "INSERT INTO dim_region(region_id, region_name) VALUES (?, ?)",
            [(item.region_id, item.region_name) for item in regions],
        )
        conn.executemany(
            "INSERT INTO dim_store(store_id, store_name, region_id) VALUES (?, ?, ?)",
            [(item.store_id, item.store_name, item.region_id) for item in stores],
        )
        conn.executemany(
            "INSERT INTO dim_category(category_id, category_name) VALUES (?, ?)",
            [(item.category_id, item.category_name) for item in categories],
        )
        conn.executemany(
            "INSERT INTO dim_product(product_id, product_name, category_id) VALUES (?, ?, ?)",
            [(item.product_id, item.product_name, item.category_id) for item in products],
        )

        for day in iter_dates():
            date_key = int(day.strftime("%Y%m%d"))
            conn.execute(
                """
                INSERT INTO dim_date(date_key, date, year, month, day, week_of_year, month_label)
                VALUES (?, ?, ?, ?, ?, ?, ?)
                """,
                (date_key, day.isoformat(), day.year, day.month, day.day, int(day.strftime("%W")), f"{day.year}-{day.month:02d}"),
            )

        region_factor = {1: 1.15, 2: 1.06, 3: 1.12, 4: 0.96, 5: 1.02, 6: 0.88}
        category_factor = {1: 1.18, 2: 1.09, 3: 0.95, 4: 0.91}
        price_map = {1: 9.9, 2: 18.0, 3: 49.0, 4: 12.9, 5: 39.9, 6: 16.9, 7: 59.0, 8: 79.0}

        fact_rows: list[tuple[object, ...]] = []
        for day in iter_dates():
            date_key = int(day.strftime("%Y%m%d"))
            weekday_factor = 1.14 if day.weekday() in (4, 5, 6) else 0.96
            month_factor = 1.18 if day.month in (6, 11, 12) else 1.0
            for store in stores:
                for product in products:
                    price = price_map[product.product_id]
                    base_orders = 22 + (store.store_id % 4) * 6 + (product.product_id % 3) * 4
                    seasonality = region_factor[store.region_id] * category_factor[product.category_id] * weekday_factor * month_factor
                    noise = random.uniform(0.82, 1.24)
                    order_count = max(6, int(base_orders * seasonality * noise))
                    quantity = order_count + random.randint(0, order_count // 3)
                    gross_sales = round(quantity * price * random.uniform(0.97, 1.06), 2)
                    refund_amount = round(gross_sales * random.uniform(0.01, 0.08), 2)
                    net_sales = round(gross_sales - refund_amount, 2)
                    new_customer_count = max(1, int(order_count * random.uniform(0.12, 0.32)))
                    returning_customer_count = max(1, int(order_count * random.uniform(0.28, 0.55)))
                    active_customer_count = max(new_customer_count + returning_customer_count, int(order_count * random.uniform(0.7, 0.95)))

                    fact_rows.append(
                        (
                            date_key,
                            store.region_id,
                            store.store_id,
                            product.product_id,
                            order_count,
                            quantity,
                            gross_sales,
                            refund_amount,
                            net_sales,
                            new_customer_count,
                            returning_customer_count,
                            active_customer_count,
                        )
                    )

        conn.executemany(
            """
            INSERT INTO fact_sales(
                date_key, region_id, store_id, product_id, order_count, quantity,
                gross_sales, refund_amount, net_sales, new_customer_count,
                returning_customer_count, active_customer_count
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            fact_rows,
        )
        conn.commit()

    print(f"Seeded demo database at: {DB_PATH}")


if __name__ == "__main__":
    seed()
