from __future__ import annotations

import json
from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parents[1]
KB_ROOT = PROJECT_ROOT / "knowledge_base"
OUTPUT_PATH = KB_ROOT / "index.json"


def extract_title(path: Path, content: str) -> str:
    for line in content.splitlines():
        line = line.strip()
        if line.startswith("# "):
            return line[2:].strip()
    return path.stem


def main() -> None:
    records: list[dict[str, object]] = []
    for file_path in sorted(KB_ROOT.rglob("*.md")):
        content = file_path.read_text(encoding="utf-8").strip()
        if not content:
            continue
        records.append(
            {
                "title": extract_title(file_path, content),
                "source": str(file_path.relative_to(PROJECT_ROOT)),
                "category": file_path.parent.name,
                "content": content,
                "tags": [file_path.parent.name, file_path.stem],
            }
        )

    OUTPUT_PATH.write_text(json.dumps(records, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"Indexed {len(records)} knowledge documents to {OUTPUT_PATH}")


if __name__ == "__main__":
    main()
