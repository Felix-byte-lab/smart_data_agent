# 智能问数 Agent（V1）

一个基于虚拟经营数据、知识库检索和受控 SQL 查询的智能问数演示项目。

这个项目满足两条约束：

- 不使用任何公司真实数据
- 不依赖 GitHub，代码可本地直接交付与运行

## 1. 项目能力

- 自然语言问数
- 指标口径 / FAQ 知识库检索
- SQL 自动生成与安全校验
- 结果图表展示
- 多轮会话上下文
- 本地虚拟零售经营数据

## 2. 技术栈

- 前端：Next.js 16 + React 19 + Tailwind CSS
- 后端：FastAPI + Pydantic
- 数据库：SQLite
- 知识库：本地 Markdown 文档 + 轻量索引

## 3. 项目结构

```text
smart-data-agent/
  frontend/              # Next.js 前端
  backend/               # FastAPI 后端
  data/
    sqlite/demo.sqlite3  # 虚拟数据库
    seed/                # 预留种子目录
  knowledge_base/        # 指标、Schema、FAQ、规则文档
  scripts/               # 数据和知识库构建脚本
  DESIGN.md              # 项目内设计约束
  docker-compose.yml
  .env.example
```

## 4. 本地启动

### 4.1 启动后端

```bash
cd smart-data-agent/backend
pip3 install -r requirements.txt
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

### 4.2 启动前端

```bash
cd smart-data-agent/frontend
npm install
npm run dev -- --hostname 0.0.0.0
```

打开：

- 前端：http://localhost:3000
- 后端：http://localhost:8000
- 健康检查：http://localhost:8000/health

## 5. 重新生成数据与知识库

### 5.1 重新生成虚拟数据库

```bash
cd smart-data-agent
python3 scripts/seed_demo_data.py
```

### 5.2 重建知识库索引

```bash
cd smart-data-agent
python3 scripts/rebuild_knowledge_base.py
```

## 6. 主要接口

### 6.1 问数接口

`POST /api/v1/chat/query`

请求示例：

```json
{
  "question": "本月华东区销售额是多少？",
  "session_id": "optional-session-id"
}
```

### 6.2 知识库列表

`GET /api/v1/knowledge/documents`

### 6.3 应用配置

`GET /api/v1/config`

## 7. 推荐体验问题

- 本月华东区销售额是多少？
- 销售额按区域拆分看看
- 退款率和上个月比怎么样？
- GMV 和销售额有什么区别？
- 新客数按门店排名 Top 5

## 8. 默认实现说明

### 8.1 当前的“智能”来源

V1 默认采用“规则解析 + 知识检索 + SQL 生成”的方式完成主链路，因此项目开箱即可运行，不强依赖外部模型服务。

### 8.2 可选接入 LLM

如果你后续希望增强解析或回答表达，可以在 `.env` 里配置 OpenAI 兼容接口：

```bash
ENABLE_LLM=true
OPENAI_API_KEY=your-key
OPENAI_BASE_URL=https://your-openai-compatible-endpoint
OPENAI_MODEL=gpt-4o-mini
```

当前代码已预留环境变量，但默认不开启。

## 9. 已完成验证

- `python3 scripts/seed_demo_data.py`
- `python3 scripts/rebuild_knowledge_base.py`
- `npm run lint`
- `npm run build`
- FastAPI TestClient 调用 `POST /api/v1/chat/query`

## 10. 后续可扩展方向

- 增加更多指标与更复杂的 NL2SQL 解析
- 增加更完整的知识库分块与向量检索
- 接入真实模型做意图理解与回答润色
- 支持更多图表和异常诊断分析
