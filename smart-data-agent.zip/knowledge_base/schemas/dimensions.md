# 维表与分析维度说明

dim_region 提供区域名称。

dim_store 提供门店名称与所属区域。

dim_product 提供商品名称与所属品类。

dim_category 提供品类名称。

dim_date 提供日期、月份和周序信息，适合做趋势分析和时间过滤。
