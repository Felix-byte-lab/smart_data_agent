# fact_sales 表说明

fact_sales 是本项目的核心经营事实表，粒度为 日期 × 区域 × 门店 × 商品。

关键字段包括：

- order_count：订单数
- quantity：销量
- gross_sales：毛成交额
- refund_amount：退款金额
- net_sales：净销售额
- new_customer_count：新客数
- returning_customer_count：复购客户数
- active_customer_count：活跃客户数

查询区域、门店、品类和商品时，需要联合 dim_region、dim_store、dim_product、dim_category。
